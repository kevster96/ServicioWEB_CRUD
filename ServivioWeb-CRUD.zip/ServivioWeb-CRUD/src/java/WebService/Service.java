/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebService;

import Modelo.LibroDAO;
import Modelo.LibroVO;
import java.util.ArrayList;
import javax.jws.Oneway;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author kevin
 */
@WebService(serviceName = "Service")
public class Service {

LibroDAO ldao= new LibroDAO();
LibroVO lvo = new LibroVO();

    @WebMethod(operationName = "mostrar")
    public ArrayList<LibroVO> mostrar() {
        //TODO write your implementation code here:
        ArrayList datos =ldao.consultarTabla();
        return datos;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "insetar")
    
    public LibroVO insetar(
            @WebParam(name = "nombre") String nombre, 
            @WebParam(name = "autor") String autor, 
            @WebParam(name = "paginas") int paginas, 
            @WebParam(name = "idioma") String idioma, 
            @WebParam(name = "editorial") String editorial) {
        lvo.setNombre(nombre);
        lvo.setAutor(autor);
        lvo.setPaginas(paginas);
        lvo.setIdioma(idioma);
        lvo.setEditorial(editorial);
        ldao.insertar(lvo);
        
        return lvo;
        
    }

  
    @WebMethod(operationName = "consultaID")
    public LibroVO consultaID(@WebParam(name = "id") int id) {
        //TODO write your implementation code here:
        lvo = ldao.consultarID(id);
        return lvo;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "eliminar")
   
    public LibroVO eliminar(@WebParam(name = "id") int id) {
        lvo =  ldao.eliminar(id);
        return lvo;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "modificar")
    public LibroVO modificar(
            @WebParam(name = "id") int id,
            @WebParam(name = "nombre") String nombre, 
            @WebParam(name = "autor") String autor, 
            @WebParam(name = "paginas") int paginas, 
            @WebParam(name = "idioma") String idioma, 
            @WebParam(name = "editorial") String editorial) {
        //TODO write your implementation code here:
        lvo.setId(id);
        lvo.setNombre(nombre);
        lvo.setAutor(autor);
        lvo.setPaginas(paginas);
        lvo.setIdioma(idioma);
        lvo.setEditorial(editorial);
        ldao.modificar(lvo);
        return lvo;
    }
}
