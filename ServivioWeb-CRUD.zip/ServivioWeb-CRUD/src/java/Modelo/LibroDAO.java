/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author kevin
 */
import java.util.ArrayList;
import java.sql.ResultSet;

/**
 *
 * @author kevin
 */
public class LibroDAO implements ConsultaDAO{

    @Override
    public ArrayList<LibroVO> consultarTabla() {
       Conector con = new Conector();
       con.conectar();
       ArrayList<LibroVO> info = new ArrayList<>();
       ResultSet rs = con.consulta("SELECT * FROM tbl_libro;");
       try{
           while(rs.next()){
           LibroVO lvo = new LibroVO();
           lvo.setId(rs.getInt(1));
           lvo.setNombre(rs.getString(2));
           lvo.setAutor(rs.getString(3));
           lvo.setPaginas(rs.getInt(4));
           lvo.setIdioma(rs.getString(5));
           lvo.setEditorial(rs.getString(6));
           info.add(lvo);
           }
       }catch(Exception e){
           System.err.println(""+e.getMessage());
       }
       con.desconectar();
       return info;
    }

    @Override
    public LibroVO consultarID(int id) {
          Conector con = new Conector();
          con.conectar();
          ResultSet rs = con.consulta("SELECT * FROM tbl_libro WHERE id="+id+";");
          LibroVO lvo = new LibroVO();
          try{
              
           while(rs.next()){
          
          lvo.setId(id);
          lvo.setNombre(rs.getString(2));
          lvo.setAutor(rs.getString(3));
          lvo.setPaginas(rs.getInt(4));
          lvo.setIdioma(rs.getString(5));
          lvo.setEditorial(rs.getString(6));
          }
          }catch(Exception e){
         
          }
          con.desconectar();
          return lvo;
    }

    @Override
    public void insertar(LibroVO lvo) {
         Conector con = new Conector();
       con.conectar();
       try{
          con.consulta_multiple("INSERT INTO tbl_libro (nombre,autor,paginas,idioma,editorial)"
                  + " VALUES('"+lvo.getNombre()+"','"
                  +lvo.getAutor()+"',"
                  +lvo.getPaginas()+",'"
                  +lvo.getIdioma()+"','"
                  +lvo.getEditorial()+"');");
       }catch(Exception e){
           System.err.println(e.getMessage());
       }
       con.desconectar();
       
    }

    @Override
    public void modificar(LibroVO lvo) {
        Conector con = new Conector();
       con.conectar();
        try {
            con.consulta_multiple("UPDATE tbl_libro SET nombre='"+lvo.getNombre()+
                   "', autor='"+lvo.getAutor()+"', paginas="+lvo.getPaginas()+
                    ", idioma='"+lvo.getIdioma()+"', editorial='"+lvo.getEditorial()+"' WHERE id="+lvo.getId()+";");
        } catch (Exception e) {
            
        }
    con.desconectar();
    }

    @Override
    public LibroVO eliminar(int id) {
           Conector con = new Conector();
       con.conectar();
       LibroVO lvo = new LibroVO();
       try{
         con.consulta_multiple("DELETE FROM tbl_libro WHERE id="+id+";");
       }catch(Exception e){
          
       }
       con.desconectar();
       return lvo;
        }
    
}
