/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author kevin
 */
public interface ConsultaDAO {
    public ArrayList<LibroVO> consultarTabla();
    public LibroVO consultarID(int id);
    public void insertar(LibroVO lvo);
    public void modificar(LibroVO lvo);
    public LibroVO eliminar(int id);
}
